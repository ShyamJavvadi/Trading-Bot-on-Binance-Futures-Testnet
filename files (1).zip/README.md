# Simplified Trading Bot — Binance USDT-M Futures Testnet

A command-line trading bot for placing **MARKET** and **LIMIT** orders on the
**Binance USDT-M Futures Testnet**. Built with a clean, modular architecture,
full input validation, structured logging, and a polished CLI experience
powered by [Rich](https://github.com/Textualize/rich).

> ⚠️ This bot is configured to talk **only** to the Binance Futures
> **Testnet** (`https://testnet.binancefuture.com`). It never touches the
> live exchange.

---

## Features

- Place **MARKET** and **LIMIT** orders, both **BUY** and **SELL**
- Professional CLI built with `argparse`
- Thorough input validation before any API call is made
- Clean separation between CLI, validation, business logic, and the API client
- Friendly, human-readable error messages — no raw tracebacks
- Structured logging to file for every request, response, and error
- Credentials loaded from environment variables via `python-dotenv`
  (never hardcoded)
- Bonus: **Rich-powered CLI** with formatted tables and color-coded
  success/failure panels

---

## Folder Structure

```
trading_bot/
│
├── bot/
│   ├── __init__.py
│   ├── client.py            # Binance Futures Testnet API client wrapper
│   ├── orders.py             # Order execution business logic + logging
│   ├── validators.py         # Input validation rules
│   ├── logging_config.py     # Logging setup (file handlers per order type)
│
├── logs/
│   ├── market_order.log      # Sample log from a MARKET order run
│   └── limit_order.log       # Sample log from a LIMIT order run
│
├── cli.py                    # CLI entry point
├── config.py                 # Environment / settings loader
├── .env.example               # Template for required environment variables
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Installation

### 1. Clone or copy the project

```bash
cd trading_bot
```

### 2. Create and activate a virtual environment

```bash
python3 -m venv venv

# macOS / Linux
source venv/bin/activate

# Windows (PowerShell)
venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

**Dependencies:**

| Package         | Purpose                                          |
|-----------------|---------------------------------------------------|
| `python-binance`| Official-style client for the Binance API/Futures |
| `python-dotenv` | Loads credentials from a `.env` file               |
| `rich`          | Formatted, color-coded CLI output                  |
| `requests`      | HTTP client (dependency of python-binance)          |

---

## Environment Variables

The bot reads credentials from environment variables. Copy the example file
and fill in your own Testnet keys:

```bash
cp .env.example .env
```

`.env`:

```
BINANCE_API_KEY=your_testnet_api_key_here
BINANCE_API_SECRET=your_testnet_api_secret_here
```

Credentials are **never** hardcoded anywhere in the source code.

---

## How to Generate Binance Testnet API Keys

1. Go to **https://testnet.binancefuture.com**
2. Log in using a **GitHub account** (the Futures Testnet uses GitHub OAuth,
   not a regular Binance account).
3. Once logged in, locate the **API Key** panel, usually on the right-hand
   side of the dashboard (or under your account/profile menu).
4. Click **Generate HMAC_SHA256 Key** (a new key/secret pair is created
   automatically — no email verification needed on testnet).
5. Copy the **API Key** and **Secret Key** immediately — the secret is only
   shown once.
6. Paste both values into your `.env` file as shown above.
7. The Testnet account is pre-funded with mock USDT so you can place real
   test orders without risking real funds.

---

## Usage

### Run a MARKET order

```bash
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01
```

### Run a LIMIT order

```bash
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 108000
```

### CLI Arguments

| Argument      | Required          | Description                                   |
|---------------|--------------------|------------------------------------------------|
| `--symbol`    | Yes                | Trading pair, e.g. `BTCUSDT`                   |
| `--side`      | Yes                | `BUY` or `SELL`                                |
| `--type`      | Yes                | `MARKET` or `LIMIT`                            |
| `--quantity`  | Yes                | Positive order quantity                        |
| `--price`     | Only for `LIMIT`   | Limit price; must be omitted for `MARKET`      |

---

## Expected Output

Before submitting, the bot prints an order summary:

```
        Order Summary
┌────────────┬──────────┐
│ Symbol     │ BTCUSDT  │
│ Side       │ BUY      │
│ Order Type │ MARKET   │
│ Quantity   │ 0.01     │
└────────────┴──────────┘
```

After the API responds, it prints the result:

```
           Order Result
┌────────────────────┬───────────────────────────┐
│ Order ID           │ 3145678901                │
│ Status             │ FILLED                    │
│ Executed Quantity  │ 0.01                      │
│ Average Price      │ 67543.20                  │
│ Timestamp          │ 2026-06-30T21:00:00+00:00 │
└────────────────────┴───────────────────────────┘
╭──────────────────────────────────────╮
│ Order submitted successfully.        │
╰──────────────────────────────────────╯
```

On failure, a red panel with a clear, human-readable message is shown instead
of a traceback, e.g.:

```
╭──────────────────────────────────────────────────────────╮
│ Order failed: Authentication error - Authentication       │
│ failed. Check that BINANCE_API_KEY and                    │
│ BINANCE_API_SECRET are valid Testnet credentials.          │
╰──────────────────────────────────────────────────────────╯
```

---

## Logging

- All logs are written to the `logs/` directory at the project root.
- Each order type gets its own log file:
  - `logs/market_order.log`
  - `logs/limit_order.log`
- Each log entry includes:
  - Timestamp
  - The API endpoint called
  - The full request payload
  - The full response (on success)
  - Errors and exceptions (on failure), including stack traces
- Sample log files generated from one MARKET order and one LIMIT order run
  are included in the `logs/` directory so you can see the expected format
  without running the bot yourself.
- Logs are also mirrored to the console at `WARNING` level and above, so
  errors are visible immediately without opening the log file.

---

## Error Handling

The bot never crashes with a raw, unreadable traceback. All errors are
caught and mapped to a clear message:

| Scenario                       | Behavior                                          |
|---------------------------------|----------------------------------------------------|
| Invalid/missing CLI arguments   | `argparse` prints usage help and a clear error     |
| Invalid symbol                  | Validation error before any API call is made        |
| Missing price on LIMIT order    | Validation error: "LIMIT orders require a --price"  |
| Price supplied on MARKET order  | Validation error: price must not be set             |
| Negative or zero quantity       | Validation error: "Quantity must be positive"        |
| Invalid/expired API credentials | `AuthenticationError` with a friendly message        |
| Network failure / timeout       | `NetworkError` with a friendly message               |
| Any other Binance API error     | `ExchangeAPIError` with the API's error message       |
| Any unexpected exception        | Caught at the top level and reported cleanly          |

---

## Troubleshooting

**"Authentication error" even though my keys look correct**
Make sure you generated the keys from **testnet.binancefuture.com**, not
the main Binance site or Binance Spot Testnet — Futures Testnet keys are
separate. Also confirm there's no leading/trailing whitespace in your `.env`
file.

**"Network error - ..." on every request**
Check your internet connection and firewall settings. Some corporate
networks block access to `testnet.binancefuture.com`.

**`ModuleNotFoundError: No module named 'binance'`**
Activate your virtual environment and reinstall dependencies:
`pip install -r requirements.txt`.

**Order stays in `NEW` status with no `Average Price`**
This is expected for LIMIT orders that haven't been filled yet — the
Testnet order book may not have matching liquidity at your limit price.
The order is still successfully placed; check the Testnet web UI to
monitor it.

**I want to test without real network access**
The `bot/client.py` module isolates all Binance calls behind
`BinanceFuturesTestnetClient`, so it can be mocked/stubbed in unit tests
without hitting the network.

---

## Assumptions

- Only **USDT-M Futures** pairs are supported (symbols ending in `USDT`),
  matching the project's scope.
- LIMIT orders are always placed with `timeInForce="GTC"` (Good-Til-Canceled),
  since the spec does not request configurable time-in-force.
- The bot is a one-shot CLI tool (place one order per invocation), not a
  long-running daemon or automated strategy engine.
- "Average Price" is reported as `N/A (order not yet filled)` when Binance
  returns `0`, which is normal for unfilled LIMIT orders.
- API keys are assumed to be valid **Futures Testnet** keys, not Spot or
  live-exchange keys.

---

## Bonus Feature: Enhanced CLI Experience (Rich)

This project's bonus feature is a **Rich-powered CLI experience**:

- The order summary and order result are rendered as clean, aligned tables.
- Success and failure messages are shown in color-coded panels (green for
  success, red for failure) instead of plain `print()` statements.
- Output remains fully readable in plain terminals and CI logs, since Rich
  gracefully degrades when color isn't supported.

---

## Disclaimer

This project is for educational purposes and interacts exclusively with the
Binance **Futures Testnet**. Do not point it at production Binance endpoints
without a thorough security and risk review.
