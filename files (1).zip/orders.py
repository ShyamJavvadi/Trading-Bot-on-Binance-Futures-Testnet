"""
Order placement business logic for the Simplified Trading Bot.

This module sits between the CLI and the Binance client wrapper. It logs
every request/response, normalizes the API response into a simple result
object, and keeps all order-related business rules out of the CLI layer.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from bot.client import BinanceFuturesTestnetClient, TradingBotClientError
from bot.logging_config import get_order_type_logger
from bot.validators import OrderRequest

FUTURES_ORDER_ENDPOINT = "/fapi/v1/order"


@dataclass
class OrderResult:
    """Normalized result of a successfully placed order."""

    order_id: Any
    status: str
    executed_qty: Optional[str]
    avg_price: Optional[str]
    timestamp: str
    raw_response: Dict[str, Any]


class OrderExecutionError(Exception):
    """Raised when an order could not be placed, wrapping the root cause."""


class OrderExecutor:
    """Executes validated order requests against the Binance Futures Testnet."""

    def __init__(self, client: BinanceFuturesTestnetClient) -> None:
        """
        Args:
            client: A configured `BinanceFuturesTestnetClient` instance.
        """
        self._client = client

    def execute(self, order: OrderRequest) -> OrderResult:
        """
        Submit a validated order to Binance and log the full request/response.

        Args:
            order: A validated `OrderRequest`.

        Returns:
            An `OrderResult` describing the outcome.

        Raises:
            OrderExecutionError: If the order could not be placed, wrapping
                the underlying `TradingBotClientError`.
        """
        logger = get_order_type_logger(order.order_type)
        request_payload = {
            "symbol": order.symbol,
            "side": order.side,
            "type": order.order_type,
            "quantity": order.quantity,
        }
        if order.price is not None:
            request_payload["price"] = order.price
            request_payload["timeInForce"] = "GTC"

        logger.info("Endpoint: POST %s", FUTURES_ORDER_ENDPOINT)
        logger.info("Request payload: %s", request_payload)

        try:
            if order.order_type == "MARKET":
                response = self._client.place_market_order(
                    symbol=order.symbol,
                    side=order.side,
                    quantity=order.quantity,
                )
            else:
                response = self._client.place_limit_order(
                    symbol=order.symbol,
                    side=order.side,
                    quantity=order.quantity,
                    price=order.price,
                )
        except TradingBotClientError as exc:
            logger.error("Order failed: %s", exc, exc_info=True)
            raise OrderExecutionError(str(exc)) from exc

        logger.info("Response: %s", response)
        result = self._to_result(response)
        logger.info(
            "Order placed successfully. order_id=%s status=%s",
            result.order_id,
            result.status,
        )
        return result

    @staticmethod
    def _to_result(response: Dict[str, Any]) -> OrderResult:
        """
        Normalize a raw Binance API response into an `OrderResult`.

        Args:
            response: The raw JSON response dict from Binance.

        Returns:
            An `OrderResult` with the fields relevant to CLI output.
        """
        executed_qty = response.get("executedQty")
        avg_price = response.get("avgPrice")

        # Binance returns "0" or "0.00000" for avgPrice when an order
        # hasn't been (fully) filled yet, e.g. an open LIMIT order.
        if avg_price in (None, "0", "0.00000000", "0.00000"):
            avg_price = None

        return OrderResult(
            order_id=response.get("orderId"),
            status=response.get("status", "UNKNOWN"),
            executed_qty=executed_qty,
            avg_price=avg_price,
            timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            raw_response=response,
        )
