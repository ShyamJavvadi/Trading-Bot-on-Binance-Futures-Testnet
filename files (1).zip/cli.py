#!/usr/bin/env python3
"""
Simplified Trading Bot CLI.

Command-line interface for placing MARKET and LIMIT orders on the
Binance USDT-M Futures Testnet.

Examples:
    python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01
    python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 108000

Bonus feature: enhanced CLI experience using the `rich` library for
color-coded, formatted terminal output (order summary tables, panels,
and success/failure banners).
"""

import argparse
import sys
from typing import NoReturn, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from bot.client import (
    AuthenticationError,
    BinanceFuturesTestnetClient,
    NetworkError,
    ExchangeAPIError,
    TradingBotClientError,
)
from bot.orders import OrderExecutionError, OrderExecutor, OrderResult
from bot.validators import OrderRequest, ValidationError, validate_order_request
from config import load_settings

console = Console()


def build_arg_parser() -> argparse.ArgumentParser:
    """
    Build and return the CLI argument parser.

    Returns:
        A configured `argparse.ArgumentParser`.
    """
    parser = argparse.ArgumentParser(
        prog="cli.py",
        description="Simplified Trading Bot for Binance USDT-M Futures Testnet.",
        epilog=(
            "Examples:\n"
            "  python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01\n"
            "  python cli.py --symbol BTCUSDT --side SELL --type LIMIT "
            "--quantity 0.01 --price 108000"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--symbol",
        required=True,
        help="Trading pair symbol, e.g. BTCUSDT.",
    )
    parser.add_argument(
        "--side",
        required=True,
        choices=["BUY", "SELL", "buy", "sell"],
        help="Order side: BUY or SELL.",
    )
    parser.add_argument(
        "--type",
        dest="order_type",
        required=True,
        choices=["MARKET", "LIMIT", "market", "limit"],
        help="Order type: MARKET or LIMIT.",
    )
    parser.add_argument(
        "--quantity",
        required=True,
        type=float,
        help="Order quantity (must be positive).",
    )
    parser.add_argument(
        "--price",
        required=False,
        type=float,
        default=None,
        help="Limit price. Required for LIMIT orders; must be omitted for MARKET orders.",
    )
    return parser


def print_order_summary(order: OrderRequest) -> None:
    """Print a formatted summary of the order before submission."""
    table = Table(title="Order Summary", show_header=False, title_style="bold cyan")
    table.add_row("Symbol", order.symbol)
    table.add_row("Side", order.side)
    table.add_row("Order Type", order.order_type)
    table.add_row("Quantity", str(order.quantity))
    if order.price is not None:
        table.add_row("Price", str(order.price))
    console.print(table)


def print_order_result(result: OrderResult) -> None:
    """Print a formatted summary of a successful order result."""
    table = Table(title="Order Result", show_header=False, title_style="bold green")
    table.add_row("Order ID", str(result.order_id))
    table.add_row("Status", result.status)
    table.add_row("Executed Quantity", str(result.executed_qty or "N/A"))
    table.add_row("Average Price", str(result.avg_price or "N/A (order not yet filled)"))
    table.add_row("Timestamp", result.timestamp)
    console.print(table)
    console.print(
        Panel.fit(
            "[bold green]Order submitted successfully.[/bold green]",
            border_style="green",
        )
    )


def print_failure(message: str) -> None:
    """Print a formatted failure banner with a user-friendly message."""
    console.print(
        Panel.fit(
            f"[bold red]Order failed:[/bold red] {message}",
            border_style="red",
        )
    )


def parse_and_validate(args: argparse.Namespace) -> OrderRequest:
    """
    Validate raw CLI arguments and return a validated OrderRequest.

    Raises:
        ValidationError: If any argument fails validation.
    """
    return validate_order_request(
        symbol=args.symbol,
        side=args.side,
        order_type=args.order_type,
        quantity=args.quantity,
        price=args.price,
    )


def run(argv: Optional[list] = None) -> int:
    """
    Run the CLI: parse arguments, validate, submit the order, and print
    results. Never raises — all errors are caught and reported cleanly.

    Args:
        argv: Optional list of arguments (for testing). Defaults to sys.argv.

    Returns:
        Process exit code: 0 on success, 1 on failure.
    """
    parser = build_arg_parser()

    try:
        args = parser.parse_args(argv)
    except SystemExit:
        # argparse already printed a usage error; propagate its exit code.
        raise

    try:
        order = parse_and_validate(args)
    except ValidationError as exc:
        print_failure(str(exc))
        return 1

    print_order_summary(order)

    try:
        settings = load_settings()
        client = BinanceFuturesTestnetClient(settings.api_key, settings.api_secret)
        executor = OrderExecutor(client)
        result = executor.execute(order)
    except AuthenticationError as exc:
        print_failure(f"Authentication error - {exc}")
        return 1
    except NetworkError as exc:
        print_failure(f"Network error - {exc}")
        return 1
    except ExchangeAPIError as exc:
        print_failure(f"Exchange error - {exc}")
        return 1
    except OrderExecutionError as exc:
        print_failure(str(exc))
        return 1
    except TradingBotClientError as exc:
        print_failure(str(exc))
        return 1
    except Exception as exc:  # noqa: BLE001 - top-level safety net
        print_failure(f"Unexpected error - {exc}")
        return 1

    print_order_result(result)
    return 0


def main() -> NoReturn:
    """Entry point for `python cli.py ...`."""
    sys.exit(run())


if __name__ == "__main__":
    main()
