"""
Input validation utilities for the Simplified Trading Bot.

All validation logic is centralized here so that both the CLI layer and
the order-placement layer can rely on consistent, well-tested rules
before any request is sent to the Binance API.
"""

import re
from dataclasses import dataclass
from typing import Optional


class ValidationError(Exception):
    """Raised when user-supplied input fails validation."""


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT"}

# Basic pattern for USDT-M Futures symbols, e.g. BTCUSDT, ETHUSDT.
SYMBOL_PATTERN = re.compile(r"^[A-Z0-9]{5,20}$")


@dataclass
class OrderRequest:
    """A validated, ready-to-submit order request."""

    symbol: str
    side: str
    order_type: str
    quantity: float
    price: Optional[float] = None


def validate_symbol(symbol: str) -> str:
    """
    Validate a trading pair symbol.

    Args:
        symbol: The raw symbol string, e.g. "btcusdt".

    Returns:
        The normalized (uppercased) symbol.

    Raises:
        ValidationError: If the symbol is empty or malformed.
    """
    if not symbol or not symbol.strip():
        raise ValidationError("Symbol must not be empty.")

    normalized = symbol.strip().upper()

    if not SYMBOL_PATTERN.match(normalized):
        raise ValidationError(
            f"Invalid symbol format: '{symbol}'. "
            "Expected a format like 'BTCUSDT' (letters/digits, 5-20 chars)."
        )

    if not normalized.endswith("USDT"):
        raise ValidationError(
            f"Invalid symbol: '{symbol}'. Only USDT-M pairs (e.g. BTCUSDT) "
            "are supported by this bot."
        )

    return normalized


def validate_side(side: str) -> str:
    """
    Validate an order side.

    Args:
        side: The raw side string, e.g. "buy".

    Returns:
        The normalized (uppercased) side, either "BUY" or "SELL".

    Raises:
        ValidationError: If the side is not BUY or SELL.
    """
    if not side or not side.strip():
        raise ValidationError("Side must not be empty.")

    normalized = side.strip().upper()

    if normalized not in VALID_SIDES:
        raise ValidationError(
            f"Invalid side: '{side}'. Must be one of {sorted(VALID_SIDES)}."
        )

    return normalized


def validate_order_type(order_type: str) -> str:
    """
    Validate an order type.

    Args:
        order_type: The raw order type string, e.g. "market".

    Returns:
        The normalized (uppercased) order type, either "MARKET" or "LIMIT".

    Raises:
        ValidationError: If the order type is not MARKET or LIMIT.
    """
    if not order_type or not order_type.strip():
        raise ValidationError("Order type must not be empty.")

    normalized = order_type.strip().upper()

    if normalized not in VALID_ORDER_TYPES:
        raise ValidationError(
            f"Invalid order type: '{order_type}'. "
            f"Must be one of {sorted(VALID_ORDER_TYPES)}."
        )

    return normalized


def validate_quantity(quantity: float) -> float:
    """
    Validate an order quantity.

    Args:
        quantity: The raw quantity value.

    Returns:
        The validated quantity as a float.

    Raises:
        ValidationError: If the quantity is not positive.
    """
    try:
        value = float(quantity)
    except (TypeError, ValueError):
        raise ValidationError(f"Quantity must be a number, got: '{quantity}'.")

    if value <= 0:
        raise ValidationError(f"Quantity must be positive, got: {value}.")

    return value


def validate_price(price: Optional[float], order_type: str) -> Optional[float]:
    """
    Validate an order price given the order type.

    LIMIT orders require a positive price. MARKET orders must not include
    a price at all.

    Args:
        price: The raw price value, or None.
        order_type: The normalized order type ("MARKET" or "LIMIT").

    Returns:
        The validated price for LIMIT orders, or None for MARKET orders.

    Raises:
        ValidationError: If a LIMIT order is missing a price, if the price
            is not positive, or if a MARKET order includes a price.
    """
    if order_type == "LIMIT":
        if price is None:
            raise ValidationError("LIMIT orders require a --price value.")
        try:
            value = float(price)
        except (TypeError, ValueError):
            raise ValidationError(f"Price must be a number, got: '{price}'.")
        if value <= 0:
            raise ValidationError(f"Price must be positive, got: {value}.")
        return value

    if order_type == "MARKET":
        if price is not None:
            raise ValidationError(
                "MARKET orders must not include a --price value."
            )
        return None

    raise ValidationError(f"Cannot validate price for unknown order type: '{order_type}'.")


def validate_order_request(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float],
) -> OrderRequest:
    """
    Run all field-level validators and assemble a validated OrderRequest.

    Args:
        symbol: Raw trading pair symbol.
        side: Raw order side.
        order_type: Raw order type.
        quantity: Raw order quantity.
        price: Raw order price (required only for LIMIT orders).

    Returns:
        A fully validated OrderRequest ready to be submitted to the API.

    Raises:
        ValidationError: If any field fails validation.
    """
    validated_symbol = validate_symbol(symbol)
    validated_side = validate_side(side)
    validated_order_type = validate_order_type(order_type)
    validated_quantity = validate_quantity(quantity)
    validated_price = validate_price(price, validated_order_type)

    return OrderRequest(
        symbol=validated_symbol,
        side=validated_side,
        order_type=validated_order_type,
        quantity=validated_quantity,
        price=validated_price,
    )
