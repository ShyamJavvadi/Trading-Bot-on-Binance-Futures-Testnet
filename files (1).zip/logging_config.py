"""
Logging configuration for the Simplified Trading Bot.

Sets up a file-based logger that records request payloads, API endpoints,
responses, errors, and exceptions with timestamps. Logs are written to the
`logs/` directory at the project root.
"""

import logging
import os
from pathlib import Path

# Directory where log files are stored (created if it doesn't exist).
LOGS_DIR = Path(__file__).resolve().parent.parent / "logs"

# Log message format: timestamp, log level, logger name, message.
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str, log_filename: str) -> logging.Logger:
    """
    Create and configure a logger that writes to a dedicated log file.

    Args:
        name: The logger's name, typically the calling module's __name__.
        log_filename: The filename (relative to the logs directory) to
            write log records to, e.g. "market_order.log".

    Returns:
        A configured `logging.Logger` instance that writes to both the
        specified log file and, at WARNING level and above, to the console.
    """
    os.makedirs(LOGS_DIR, exist_ok=True)
    log_path = LOGS_DIR / log_filename

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Avoid attaching duplicate handlers if the logger is fetched multiple times.
    if not logger.handlers:
        formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)

        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(formatter)

        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        logger.propagate = False

    return logger


def get_order_type_logger(order_type: str) -> logging.Logger:
    """
    Return a logger dedicated to a specific order type (MARKET or LIMIT).

    Each order type gets its own log file, e.g. "market_order.log" or
    "limit_order.log", so logs can be easily reviewed per order type.

    Args:
        order_type: Either "MARKET" or "LIMIT" (case-insensitive).

    Returns:
        A configured `logging.Logger` instance for the given order type.
    """
    normalized = order_type.strip().upper()
    filename = f"{normalized.lower()}_order.log"
    return get_logger(f"trading_bot.{normalized.lower()}", filename)
