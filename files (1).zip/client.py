"""
Binance USDT-M Futures Testnet API client wrapper.

Wraps the `python-binance` client and points it at the official Binance
Futures Testnet base URL. Centralizes authentication, connection errors,
and low-level exception translation so that higher-level modules
(orders.py, cli.py) only ever deal with friendly, typed exceptions.
"""

from typing import Any, Dict, Optional

from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceOrderException
from requests.exceptions import ConnectionError as RequestsConnectionError
from requests.exceptions import Timeout as RequestsTimeout

FUTURES_TESTNET_BASE_URL = "https://testnet.binancefuture.com"


class TradingBotClientError(Exception):
    """Base exception for all client-level errors raised by this bot."""


class AuthenticationError(TradingBotClientError):
    """Raised when the Binance API rejects the provided credentials."""


class NetworkError(TradingBotClientError):
    """Raised when a network failure or timeout prevents an API call."""


class ExchangeAPIError(TradingBotClientError):
    """Raised when the Binance API returns an error response."""


class BinanceFuturesTestnetClient:
    """
    A thin wrapper around `binance.client.Client` configured for the
    Binance USDT-M Futures Testnet.
    """

    def __init__(self, api_key: str, api_secret: str) -> None:
        """
        Initialize the client and point it at the Futures Testnet.

        Args:
            api_key: The Binance Testnet API key.
            api_secret: The Binance Testnet API secret.

        Raises:
            AuthenticationError: If api_key or api_secret are empty.
        """
        if not api_key or not api_secret:
            raise AuthenticationError(
                "Missing API credentials. Set BINANCE_API_KEY and "
                "BINANCE_API_SECRET in your environment or .env file."
            )

        self._client = Client(api_key, api_secret, testnet=True)
        # Ensure the futures endpoint explicitly targets the testnet host,
        # in case the installed python-binance version doesn't fully
        # honor the `testnet=True` flag for FUTURES_URL.
        self._client.FUTURES_URL = f"{FUTURES_TESTNET_BASE_URL}/fapi"

    def place_market_order(
        self, symbol: str, side: str, quantity: float
    ) -> Dict[str, Any]:
        """
        Place a MARKET order on the Futures Testnet.

        Args:
            symbol: Trading pair symbol, e.g. "BTCUSDT".
            side: "BUY" or "SELL".
            quantity: Order quantity.

        Returns:
            The raw JSON response from the Binance API as a dict.

        Raises:
            AuthenticationError: On invalid API credentials.
            NetworkError: On connection failure or timeout.
            ExchangeAPIError: On any other Binance API error.
        """
        return self._execute(
            self._client.futures_create_order,
            symbol=symbol,
            side=side,
            type="MARKET",
            quantity=quantity,
        )

    def place_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        time_in_force: str = "GTC",
    ) -> Dict[str, Any]:
        """
        Place a LIMIT order on the Futures Testnet.

        Args:
            symbol: Trading pair symbol, e.g. "BTCUSDT".
            side: "BUY" or "SELL".
            quantity: Order quantity.
            price: Limit price.
            time_in_force: Time-in-force policy, defaults to "GTC".

        Returns:
            The raw JSON response from the Binance API as a dict.

        Raises:
            AuthenticationError: On invalid API credentials.
            NetworkError: On connection failure or timeout.
            ExchangeAPIError: On any other Binance API error.
        """
        return self._execute(
            self._client.futures_create_order,
            symbol=symbol,
            side=side,
            type="LIMIT",
            quantity=quantity,
            price=price,
            timeInForce=time_in_force,
        )

    def _execute(self, api_call, **kwargs: Any) -> Dict[str, Any]:
        """
        Execute a python-binance API call and translate any exceptions
        into this module's friendly exception hierarchy.

        Args:
            api_call: A bound method on the underlying `Client` instance.
            **kwargs: Keyword arguments forwarded to `api_call`.

        Returns:
            The raw JSON response from the Binance API as a dict.

        Raises:
            AuthenticationError: On invalid API credentials (HTTP 401 or
                Binance error codes -2014/-2015).
            NetworkError: On connection failure or timeout.
            ExchangeAPIError: On any other Binance API or order error.
        """
        try:
            return api_call(**kwargs)
        except (RequestsConnectionError, RequestsTimeout) as exc:
            raise NetworkError(
                f"Network error while contacting Binance Futures Testnet: {exc}"
            ) from exc
        except BinanceAPIException as exc:
            if exc.status_code == 401 or exc.code in (-2014, -2015):
                raise AuthenticationError(
                    "Authentication failed. Check that BINANCE_API_KEY and "
                    "BINANCE_API_SECRET are valid Testnet credentials."
                ) from exc
            raise ExchangeAPIError(f"Binance API error [{exc.code}]: {exc.message}") from exc
        except BinanceOrderException as exc:
            raise ExchangeAPIError(f"Binance order error [{exc.code}]: {exc.message}") from exc
        except Exception as exc:  # noqa: BLE001 - final safety net
            raise ExchangeAPIError(f"Unexpected error calling Binance API: {exc}") from exc
