"""
Configuration loader for the Simplified Trading Bot.

Loads Binance Testnet API credentials from environment variables (or a
local `.env` file via python-dotenv). Credentials are never hardcoded.
"""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

# Load variables from a .env file in the project root, if present.
load_dotenv()


@dataclass(frozen=True)
class Settings:
    """Application settings sourced from the environment."""

    api_key: str
    api_secret: str
    futures_base_url: str = "https://testnet.binancefuture.com"


def load_settings() -> Settings:
    """
    Read Binance Testnet credentials from environment variables.

    Returns:
        A `Settings` instance. Missing values are returned as empty
        strings; the client layer is responsible for raising a clear
        authentication error if they're blank.
    """
    return Settings(
        api_key=os.getenv("BINANCE_API_KEY", "").strip(),
        api_secret=os.getenv("BINANCE_API_SECRET", "").strip(),
    )
